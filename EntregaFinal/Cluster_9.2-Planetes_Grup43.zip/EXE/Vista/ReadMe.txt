Compilar Vista: [Ruta]

javac *.java
java main




NOTA: Carpeta Dades conte fitxers amb Recursos, Paquests, Planetes, Universos. Poden ser carregats al sistema per fer proves.