Compilar QAP: [Ruta]

javac *.java

Executar Driver_QAP: [Ruta]

java Driver_QAP

Executar Driver_QAP amb joc de proves: [Ruta]

java Driver_QAP < JocProva_QAP.in 
