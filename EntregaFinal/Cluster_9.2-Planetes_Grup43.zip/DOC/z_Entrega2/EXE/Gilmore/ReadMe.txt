Compilar Gilmore: [Ruta]

javac *.java
java Driver_GilMore < JocProva_Gilmore.in

