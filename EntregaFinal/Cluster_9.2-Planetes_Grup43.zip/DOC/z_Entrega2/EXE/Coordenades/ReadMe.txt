Compilar Coordenades: [Ruta]

javac *.java
java Driver_Coordenades < JocProva_Coordenades.in