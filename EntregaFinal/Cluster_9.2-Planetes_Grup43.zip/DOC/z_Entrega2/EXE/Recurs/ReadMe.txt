Compilar Recurs: [Ruta]

javac *.java
java Driver_Recurs < JocProva_Recurs.in