Compilar Controlador_Domini_Planeta: [Ruta]

javac *.java

Executar Driver Controlador Planeta: [Ruta]

java Driver_Controlador_Domini_Planeta

Executar Driver Planeta amb joc de proves: [Ruta]

java Driver_Controlador_Domini_Planeta < JocProva_Controlador_Domini_Planeta.in 
