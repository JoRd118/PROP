Compilar Solucio: [Ruta]

javac *.java

Executar Driver Solucio: [Ruta]

java Driver_Solucio

Executar Driver Solucio amb joc de proves: [Ruta]

java Driver_Solucio < JocProva_Solucio.in 
