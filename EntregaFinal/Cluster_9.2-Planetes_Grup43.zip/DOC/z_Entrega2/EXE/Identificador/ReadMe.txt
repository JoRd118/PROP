Compilar Identificador: [Ruta]

javac *.java
java Driver_Identificador < JocProva_Identificador.in