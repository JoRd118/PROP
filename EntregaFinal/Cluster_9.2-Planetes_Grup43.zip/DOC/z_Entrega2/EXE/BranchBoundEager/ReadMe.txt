Compilar BranchBoundEager: [Ruta]

javac *.java
java Driver_BranchBoundEager < JocProva_BranchBoundEager.in