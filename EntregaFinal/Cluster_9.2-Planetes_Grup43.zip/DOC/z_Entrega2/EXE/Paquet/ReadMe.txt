Compilar Paquet: [Ruta]
javac *.java

Executar Driver_Paquet: [Ruta]
java Driver_Paquet

Executar Driver_Paquet amb joc de proves: [Ruta]
java Driver_Paquet < JocProva_Paquet.in
