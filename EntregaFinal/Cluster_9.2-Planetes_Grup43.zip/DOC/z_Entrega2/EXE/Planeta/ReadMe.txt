Compilar Planeta: [Ruta]

javac *.java
java Driver_Planeta < Joc_Prova_Planeta.in