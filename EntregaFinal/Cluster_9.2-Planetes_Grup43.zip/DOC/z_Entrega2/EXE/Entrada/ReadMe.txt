Compilar Entrada: [Ruta]

javac *.java

Executar Driver_Entrada: [Ruta]

java Driver_Entrada

Executar Driver_Entrada amb joc de proves: [Ruta]

java Driver_Entrada < jocProva_Entrada.in 
java Driver_Entrada < jocProva_Entrada_Mat.in 
java Driver_Entrada < jocProva_Entrada_Mat_String.in 
