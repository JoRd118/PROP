Compilar Planeta: [Ruta]

javac *.java

Executar Manualment: [Ruta]
java Driver_Univers

Executar Joc Proves: [Ruta]
java Driver_Univers < Joc_Prova_Univers.in