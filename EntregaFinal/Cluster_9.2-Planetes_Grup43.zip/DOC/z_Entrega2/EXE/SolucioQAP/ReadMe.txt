Compilar SolucioQAP: [Ruta]

javac *.java
java Driver_SolucioQAP < JocProva_SolucioQAP.in