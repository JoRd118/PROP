Compilar TST: [Ruta]

javac *.java
java Driver_TST < JocProva_TST.in