Compilar Controlador_Dades: [Ruta]

javac *.java
java Driver_Controlador_Dades < JocProva_Controlador_Dades.in