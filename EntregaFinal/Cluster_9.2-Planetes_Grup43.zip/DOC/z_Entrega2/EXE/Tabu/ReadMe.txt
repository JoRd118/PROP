Compilar Tabu: [Ruta]

javac *.java
java Driver_Tabu < JocProva_Tabu.in