Compilar bbNode: [Ruta]

javac *.java
java Driver_bbNode < JocProva_bbNode.in