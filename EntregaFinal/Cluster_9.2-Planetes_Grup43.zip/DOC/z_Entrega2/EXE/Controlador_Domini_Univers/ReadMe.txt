Compilar Controlador_Domini_Univers: [Ruta]

javac *.java

Executar Driver Controlador Univers: [Ruta]

java Driver_Controlador_Domini_Univers

Executar Driver Univers amb joc de proves: [Ruta]

java Driver_Controlador_Domini_Univers < JocProva_Controlador_Domini_Univers.in 
