Compilar Hungarian: [Ruta]

javac *.java
java Driver_HungarianAlgorithm < JocProva_HungarianAlgorithm.in

