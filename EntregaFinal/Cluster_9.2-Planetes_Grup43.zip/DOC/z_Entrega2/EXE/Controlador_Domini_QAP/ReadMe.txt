Compilar Controlador_Domini_QAP: [Ruta]

javac *.java

Executar Driver Controlador QAP: [Ruta]

java Driver_Controlador_Domini_QAP

Executar Driver QAP amb joc de proves: [Ruta]

java Driver_Controlador_Domini_QAP < JocProva_Controlador_Domini_QAP.in 
