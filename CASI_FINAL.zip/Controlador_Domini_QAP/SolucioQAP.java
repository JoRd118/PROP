import java.util.*;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;


public class SolucioQAP {

  private String planeta;
  private boolean terraformat;
  private String observacions;
  private String nomalgoritme;
  private double millorrecorregut;
  private ArrayList<bbNode> llistanodes;
  private JTree arbre;
  
  // pre: -
  // post: Es crea una solucio del QAP per defecte.
  public SolucioQAP() {
    planeta = "No definit";
    terraformat = false;
    observacions = "";
    nomalgoritme = "No definit";
    millorrecorregut = 0;
		llistanodes = new ArrayList<bbNode>();
    arbre = null;
  }

  public void imprimirSolucio() {
    System.out.println("==========================");
    System.out.println("PLANETA.......: "+planeta);
    System.out.println("--------------------------");
    System.out.println("  Algoritme...: "+nomalgoritme);
    System.out.println("  TerraFormat.: "+terraformat);
    if(observacions != "") System.out.println("  Observacions: "+observacions);
    if(terraformat) {
      System.out.println("    Millor recorregut..: "+millorrecorregut);
      //System.out.println("    Planetes solucio...: "+planetessolucio);
    }
    if(arbre != null) {
      System.out.println("--------------------------");
      System.out.println("Arbre:");
    }
    // Pintem els nodes
    if(llistanodes != null) {
      for(bbNode nn:llistanodes) nn.imprimirNode();
    }
    System.out.println("==========================");
    System.out.println();
    
    if(arbre != null) {
      // Construccio i visualitzacio de la finestra
      JFrame v = new JFrame();
      JScrollPane scroll = new JScrollPane(arbre);
      v.getContentPane().add(scroll);
      v.pack();
      v.setVisible(true);
      v.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
    
    // Si volem accedir al contingut
    if(arbre != null) {
      DefaultMutableTreeNode node = (DefaultMutableTreeNode) arbre.getModel().getRoot();
      if(node != null) {
        NodeArbre nnn = (NodeArbre) node.getUserObject();
//        System.out.println(nnn.obtenirIdNode());
      }
    }

    

  }
  
  // pre: -
  // post: Retorna el nom del planeta
  public String obtenirPlaneta() { return planeta; }
  
  // pre: -
  // post: Retorna si el planeta ha estat terraformat o no
  public boolean obtenirTerraformat() { return terraformat; }

  // pre: -
  // post: Retorna les possibles observacions sobre l'intent de
  //       terraformació del planeta
  public String obtenirObservacions() { return observacions; }
  
  // pre: -
  // post: Retorna el nom de l'algoritme que s'ha executat
  public String obtenirNomAlgoritme() { return nomalgoritme; }

  // pre: -
  // post: Retorna el millor recorregut de la terraformacío del
  //       planeta
  public double obtenirMillorRecorregut() { return millorrecorregut; }
	
  // pre: -
  // post: Retorna la llist de nodes visitats durant la 
  //       terraformacio del planeta
  public ArrayList<bbNode> obtenirLlistaNodes() { return llistanodes; }

  // pre: -
  // post: Modifica el planeta per planeta
  public void modificarPlaneta(String planeta) { this.planeta = planeta; }
  
  // pre: -
  // post: Modifica si el planeta ha estat terraformat o no
  public void modificarTerraformat(boolean terraformat) { this.terraformat = terraformat; }
 
  // pre: -
  // post: Modifica les observacions possibles de la terraformacio
  public void modificarObservacions(String observacions) { this.observacions = observacions; }
  
  // pre: -
  // post: Modifica el Nom de l'Algorisme per nomalgoritme
  public void modificarNomAlgoritme(String nomalgoritme) { this.nomalgoritme = nomalgoritme; }
  
  // pre: -
  // post: Modifica el millor recorregut de la terraformació
  public void modificarMillorRecorregut(double millorrecorregut) { this.millorrecorregut = millorrecorregut; }

  // pre: -
  // post: Modifica la llista de nodes per llistanodes
  public void modificarLlistaNodes(ArrayList<bbNode> llistanodes) { this.llistanodes = new ArrayList<bbNode>(llistanodes); }
  
  // pre: -
  // post: Assigna un arbre per la seva creació
  public void assignarArbre(DefaultMutableTreeNode mutarrel) { 
    DefaultTreeModel model = new DefaultTreeModel(mutarrel);
    this.arbre = new JTree(model);
  }

}
