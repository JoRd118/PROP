import java.util.*;
import java.io.IOException;
import java.io.Console;

public class Controlador_Domini_QAP{
    
     // private double[][] mDistancies =  { {0.0,1.0,2.0,3.0,4.0},
     // {1.0,0.0,2.0,3.0,4.0},
     // {2.0,2.0,0.0,4.0,1.0},
     // {3.0,3.0,4.0,0.0,1.0},
     // {4.0,4.0,1.0,1.0,0.0}
     // };
     
     // private int[][] mDisponibilitats =  { {1,1,1,1,0,0,1,0,0,0}, //P0
     // {0,0,0,1,0,0,1,0,1,0}, //P1
     // {1,1,0,1,0,0,1,1,1,0}, //P2
     // {0,0,1,1,1,1,0,0,0,1}, //P3
     // {1,0,0,1,0,0,0,0,0,1}  //P4
     // };
     
     
     // private int[][] mNecessitats =      { {0,1,0,0,1,0,0,1,0,0}, //P0
     // {0,0,0,1,0,0,1,0,0,0}, //P1
     // {1,0,1,0,1,0,1,0,1,1}, //P2
     // {0,0,1,0,1,0,0,1,0,0}, //P3
     // {1,1,1,0,1,1,1,0,1,1}  //P4
     // };
     
     // private String[] mPlanetes = {"P0","P1","P2","P3","P4"};
     // private String[] mRecursos = {"r0","r1","r2","r3","r4","r5","r6","r7","r8","r9"};
     /*
     public void run_algorithm(String algorithm, String cota){
     // Preparem dades per calcular la millor solucio per cada planeta
     for(int ipclc = 0;ipclc<mPlanetes.length;ipclc++) {
     //int ipclc = 4;
     if(algorithm == "BBL") {
     BranchBound bb = new BranchBoundLazy();
     SolucioQAP solucio = bb.Calcular(ipclc, mPlanetes, mRecursos, mDistancies, mDisponibilitats, mNecessitats);
     solucio.imprimirSolucio();
     } else if(algorithm == "BBE") {
     BranchBound bb = new BranchBoundEager();
     SolucioQAP solucio = bb.Calcular(ipclc, mPlanetes, mRecursos, mDistancies, mDisponibilitats, mNecessitats);
     solucio.imprimirSolucio();
     } else if(algorithm == "TABU") {
     Tabu tb = new Tabu();
     SolucioQAP solucio = tb.Calcular(ipclc, mPlanetes, mRecursos, mDistancies, mDisponibilitats, mNecessitats);
     //        solucio.imprimirSolucio();
     }
     
     */
    private ArrayList<SolucioQAP> solucio;
    private Entrada e;
    private Controlador_Dades_QAP t;
    //Matrius
    //private double[][] mDistancies;
    //private int[][] mDisponibilitats;
    //private int[][] mNecessitats;
    
    private double [][] mDistancies =  { {0.0,5.0,3.0,10.0},
    {5.0,0.0,8.0,5.0},
    {3.0,8.0,0.0,13.0},
    {10.0,5.0,13.0,0.0}
    };
    private int[][]  mNecessitats = {{0,1,0,1,0},
    {0,1,1,0,0},
    {1,0,0,0,0},
    {1,0,0,1,0}
    };
    private int[][]  mDisponibilitats = {{1,0,1,0,0},
    {0,0,1,1,0},
    {0,0,0,1,0},
    {0,1,0,0,1}
    };

    //Vectors
    //private String[] mPlanetes;
    //private String[] mRecursos;
    
    private String[] mPlanetes = {"A","B","C","E"};
    private String[]   mRecursos = {"Coure","Diamant", "Metall", "Or", "Plata"};
    
    
    
    
    private static String msg_QAP = "Error de QAP: Algorisme no trobat";
    
    
    public Controlador_Domini_QAP(){
        e = new Entrada();
    }
    
    public Controlador_Domini_QAP(Entrada e){
        this.e = e;
        t = new Controlador_Dades_QAP();
    }
    
    public void calcularMatrius(String nom_u){
        e.calcularMatrius(nom_u);
    }
    
    public void run_algorithm(String algorithm){
        //mDistancies = e.obtenirMatriuDisPla();
        //mDisponibilitats = e.obtenirMatriuRecPla();
        //mNecessitats = e.obtenirMatriuNecPla();
        
        //mPlanetes = e.obtenirVectorPlan();
        //mRecursos = e.obtenirVectorRecu();
        
        //SolucioQAP s_aux;
        for(int ipclc = 0;ipclc<mPlanetes.length;ipclc++) {
            if(algorithm.equals("BBL")) {
                BranchBound bb = new BranchBoundLazy();
                
                SolucioQAP s_aux = bb.Calcular(ipclc, mPlanetes, mRecursos, mDistancies, mDisponibilitats, mNecessitats);
                s_aux.imprimirSolucio();
                //solucio.add(s_aux);
                System.out.println("BB DONE!");
            } else if(algorithm.equals("BBE")) {
                // BranchBound bb = new BranchBoundEager();
                // SolucioQAP s_aux = bb.Calcular(ipclc, mPlanetes, mRecursos, mDistancies, mDisponibilitats, mNecessitats);
                // s_aux.imprimirSolucio();
                // solucio.add(s_aux);
            } else if(algorithm.equals("TABU")) {
                System.out.println("Not implemented");
            }
            else{throw new IllegalArgumentException(msg_QAP);}
        }
    }
    
    public String printSolucioQAP(){
        String sol_text = new String();
        for(int i = 0; i < solucio.size(); ++i){
            sol_text = sol_text + solucio.get(i).obtenirPlaneta();
        }
        return sol_text;
    }
    /*
    public void guardar_matrius(String nomFitxer)throws IOException{
        t.writeTextFile(nomFitxer, printSolucioQAP());
    }
    */
    public void guardar_solucioQAP(String nomFitxer)throws IOException{
        ArrayList<String> sol_text = new ArrayList<String>();
        for(int i = 0; i < solucio.size(); ++i){
            sol_text.add(solucio.get(i).obtenirPlaneta());
        }
                 t.writeTextFile(nomFitxer, sol_text);
    }
    
    
}